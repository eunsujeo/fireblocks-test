---
title: 출금 화이트리스트
description: 조건 하나가 수집 루프 전체를 발동합니다
---

export const base = import.meta.env.BASE_URL.replace(/\/$/, "");

{/* 뷰어는 1440×900 데스크톱 기준의 자체 완결형 HTML이라 본문 칸(약 720px)에 그대로 넣으면 잘린다.
    iframe을 1440×900으로 고정하고 칸 폭에 맞춰 축소한다 — 상호작용은 전체 화면·새 탭에서 한다. */}
<script is:inline data-astro-rerun>{`
(function () {
  var W = 1440, H = 900;
  function fit(w) {
    var f = w.querySelector("iframe");
    var fs = document.fullscreenElement === w;
    var s = fs ? Math.min(innerWidth / W, innerHeight / H) : w.clientWidth / W;
    f.style.transform = "scale(" + s + ")";
    w.style.height = fs ? "100%" : Math.round(H * s) + "px";
    f.style.left = fs ? Math.round((innerWidth - W * s) / 2) + "px" : "0";
    f.style.top = fs ? Math.round((innerHeight - H * s) / 2) + "px" : "0";
  }
  function fitAll() { document.querySelectorAll(".dg-wrap").forEach(fit); }
  window.__dgFit = fit;
  window.__dgFull = function (btn) {
    var w = btn.closest("figure").querySelector(".dg-wrap");
    (w.requestFullscreen || w.webkitRequestFullscreen).call(w);
  };
  addEventListener("resize", fitAll);
  addEventListener("fullscreenchange", fitAll);
  if (document.readyState !== "loading") fitAll(); else addEventListener("DOMContentLoaded", fitAll);
})();
`}</script>

export function Diagram({ name, title }) {
  const src = `${base}/diagrams/${name}.html`;
  return (
    <figure class="dg" style="display:grid;gap:0;margin:.75rem 0 2.5rem 0">
      <div class="dg-wrap" style="margin:0;position:relative;overflow:hidden;width:100%;height:450px;border:1px solid var(--color-border,#e5e7eb);border-radius:8px 8px 0 0;background:#fff">
        <iframe
          src={src}
          title={title}
          loading="lazy"
          onload="window.__dgFit && window.__dgFit(this.parentElement)"
          style="position:absolute;left:0;top:0;width:1440px;height:900px;border:0;transform-origin:0 0"
        ></iframe>
      </div>
      <figcaption style="margin:0;display:flex;gap:.6rem;justify-content:flex-end;align-items:center;padding:.55rem .75rem;border:1px solid var(--color-border,#e5e7eb);border-top:0;border-radius:0 0 8px 8px;font-size:.95rem">
        <span style="margin-right:auto;opacity:.6;font-size:.85rem">축소 미리보기 — 상호작용은 전체 화면에서</span>
        <button type="button" onclick="window.__dgFull(this)" style="display:inline-flex;align-items:center;gap:.4rem;cursor:pointer;padding:.45rem .9rem;border:1px solid var(--color-border,#e5e7eb);border-radius:8px;background:transparent;font:inherit;font-size:.95rem;font-weight:600;color:inherit;line-height:1">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 3H5a2 2 0 0 0-2 2v3"/><path d="M21 8V5a2 2 0 0 0-2-2h-3"/><path d="M3 16v3a2 2 0 0 0 2 2h3"/><path d="M16 21h3a2 2 0 0 0 2-2v-3"/></svg>
          전체 화면
        </button>
        <a href={src} target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:.4rem;padding:.45rem .9rem;border:1px solid var(--color-border,#e5e7eb);border-radius:8px;text-decoration:none;font-size:.95rem;font-weight:600;color:inherit;line-height:1">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/></svg>
          새 탭에서 열기
        </a>
      </figcaption>
    </figure>
  );
}

_읽는 사람: 구현팀. 수집 루프가 끼는 평가 한 건을 처음부터 끝까지 다룹니다._

이 페이지는 외부 주소 출금 요청이 화이트리스트 등재 상태를 확인받는 과정을 따라갑니다.
화이트리스트는 출금 통제에서 부르는 주소록의 다른
이름입니다([자세히](/fund-flows/address-book)).

**이 흐름의 룰은 하나이고 조건도 하나입니다.** 그런데 그 조건이 읽는 값이 요청 안에 없어서,
평가는 한 번으로 끝나지 않습니다.

<Diagram name="usecase-whitelist-loop" title="출금 화이트리스트 — 수집 루프가 있는 평가" />

## 룰 형태가 흐름을 정합니다

외부 주소 출금을 허가하는 룰의 형태 예시입니다. 필드와 조각의 뜻은
[룰 구조](/policy/rule/structure)에 있습니다.

```json
{
  "id": "withdrawal/allow-evm-external-address",
  "effect": "allow",
  "scope": {
    "all": [
      { "field": "operation", "op": "eq", "value": "value_transfer" },
      { "field": "chain.family", "op": "eq", "value": "evm" },
      { "field": "destination.type", "op": "eq", "value": "external_address" },
      { "field": "source_vault.kind", "op": "eq", "value": "custody" }
    ]
  },
  "when": { "field": "address_ownership.status", "op": "eq", "value": "active" }
}
```

**적용 범위는 조건 필드 네 개를 전부 긍정으로 확정합니다.** 부정으로 좁히면 새 체인이나 새
목적지 종류가 등재되는 순간 이 룰이 그것까지 자동으로 함께 허용하기 때문입니다.

이 모듈에 deny 룰이 없어도 미저작 경로는 전부 막힙니다. 매치되는 allow가 없으면 결과는
default deny입니다. 결합 규칙은 [결정과 결합](/policy/rule/decision)에 있습니다.

## 조건의 소스 참조가 루프를 만듭니다

**`when`이 읽는 등재 상태는 요청이 담아 오는 값이 아닙니다.** 판단에 필요한 사실을 평가 시점에
읽어 오는 수집 경로인 PIP([자세히](/policy/runtime/pip))가 가져오고, 첫 평가 시점에는 그 스냅샷이
없습니다.

그래서 1차 평가는 거부가 아니라 `need_more_data`로 끝납니다. 그 뒤의 수집 대기와 도착 검사,
타임아웃은 [비동기 수집](/policy/sequences/pending-data)에 있습니다.

## 화이트리스트 판정이 조건에 있는 것이 의도입니다

**같은 비교를 적용 범위에 두면 미등재 주소가 "룰 없음" 거부와 구분되지 않습니다.** 조건에 두면
룰이 적용됐으나 불허한 것이 되어, 결정 사유가 모듈과 룰을 지목합니다.

등재 여부가 아니라 상태 값 하나를 봅니다. 회수는 등재 삭제가 아니라 상태 전이라서, `active`
비교 하나가 미등재와 회수를 함께 막습니다.

## 통과의 끝은 allow가 아니라 스탬프 있는 allow입니다

**재평가가 allow를 내면 승인 스탬프가 함께 새겨집니다.** 그 스탬프에 담기는 것은 인가 유효 시한과
체인별 자원 상한입니다. 승인 스탬프는 승인 시점에 찍히는 소비 시점
유효값입니다([자세히](/policy/runtime/normalization)).

스탬프를 낼 수 없으면 조건 트리를 평가하고 결정을 결합하는 정책 무관 고정 부분인
커널([자세히](/policy/rule/decision))이 allow 대신 실패로 종결합니다.

그 스탬프가 서명 직전에 하는 일은 [서명 상한 대조](/policy/use-cases/callback-limit)가 잇습니다.

## 다음으로

- [비동기 수집](/policy/sequences/pending-data) — 수집 대기·도착 검사·타임아웃
- [PIP](/policy/runtime/pip) — 소스 선언과 수집 계약
- [서명 상한 대조](/policy/use-cases/callback-limit) — 이 흐름이 발급한 스탬프의 마지막 일
