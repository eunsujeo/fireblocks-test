---
title: 평가의 순간
description: 입력 문서가 조립되고 커널이 슬롯을 풀어 결정을 내리기까지
---

export const base = import.meta.env.BASE_URL.replace(/\/$/, "");

{/* 뷰어는 1440×900 데스크톱 기준의 자체 완결형 HTML이라 본문 칸(약 720px)에 그대로 넣으면 잘린다.
    iframe을 1440×900으로 고정하고 칸 폭에 맞춰 축소한다 — 상호작용은 전체 화면·새 탭에서 한다. */}
<script is:inline data-astro-rerun>{`
(function () {
  var W = 1440, H = 900;
  function fit(w) {
    var f = w.querySelector("iframe");
    var fs = document.fullscreenElement === w;
    var s = fs ? Math.min(innerWidth / W, innerHeight / H) : w.clientWidth / W;
    f.style.transform = "scale(" + s + ")";
    w.style.height = fs ? "100%" : Math.round(H * s) + "px";
    f.style.left = fs ? Math.round((innerWidth - W * s) / 2) + "px" : "0";
    f.style.top = fs ? Math.round((innerHeight - H * s) / 2) + "px" : "0";
  }
  function fitAll() { document.querySelectorAll(".dg-wrap").forEach(fit); }
  window.__dgFit = fit;
  window.__dgFull = function (btn) {
    var w = btn.closest("figure").querySelector(".dg-wrap");
    (w.requestFullscreen || w.webkitRequestFullscreen).call(w);
  };
  addEventListener("resize", fitAll);
  addEventListener("fullscreenchange", fitAll);
  if (document.readyState !== "loading") fitAll(); else addEventListener("DOMContentLoaded", fitAll);
})();
`}</script>

export function Diagram({ name, title }) {
  const src = `${base}/diagrams/${name}.html`;
  return (
    <figure class="dg" style="display:grid;gap:0;margin:.75rem 0 2.5rem 0">
      <div class="dg-wrap" style="margin:0;position:relative;overflow:hidden;width:100%;height:450px;border:1px solid var(--color-border,#e5e7eb);border-radius:8px 8px 0 0;background:#fff">
        <iframe
          src={src}
          title={title}
          loading="lazy"
          onload="window.__dgFit && window.__dgFit(this.parentElement)"
          style="position:absolute;left:0;top:0;width:1440px;height:900px;border:0;transform-origin:0 0"
        ></iframe>
      </div>
      <figcaption style="margin:0;display:flex;gap:.6rem;justify-content:flex-end;align-items:center;padding:.55rem .75rem;border:1px solid var(--color-border,#e5e7eb);border-top:0;border-radius:0 0 8px 8px;font-size:.95rem">
        <span style="margin-right:auto;opacity:.6;font-size:.85rem">축소 미리보기 — 상호작용은 전체 화면에서</span>
        <button type="button" onclick="window.__dgFull(this)" style="display:inline-flex;align-items:center;gap:.4rem;cursor:pointer;padding:.45rem .9rem;border:1px solid var(--color-border,#e5e7eb);border-radius:8px;background:transparent;font:inherit;font-size:.95rem;font-weight:600;color:inherit;line-height:1">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 3H5a2 2 0 0 0-2 2v3"/><path d="M21 8V5a2 2 0 0 0-2-2h-3"/><path d="M3 16v3a2 2 0 0 0 2 2h3"/><path d="M16 21h3a2 2 0 0 0 2-2v-3"/></svg>
          전체 화면
        </button>
        <a href={src} target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:.4rem;padding:.45rem .9rem;border:1px solid var(--color-border,#e5e7eb);border-radius:8px;text-decoration:none;font-size:.95rem;font-weight:600;color:inherit;line-height:1">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/></svg>
          새 탭에서 열기
        </a>
      </figcaption>
    </figure>
  );
}

_읽는 사람: 구현팀. 입력 문서가 조립되고 커널이 결정을 내기까지의 순서를 다룹니다._

평가의 순간은 발행된 번들이 실제 요청 하나를 판정하는 지점입니다. Orchestrator는 판단 요청을
접수하고 입력 문서를 조립하는 정책 엔진의 앞단입니다([자세히](/policy/architecture)). 그것이
요청·환경·PIP 결과를 모아 입력 문서 하나를 만듭니다. 완성된 입력 문서를 평가해 결정을 내는
평가기(PDP)가 그 문서를 받아 룰을 적용하고 슬롯을 풀어 결정을 냅니다.

결정값의 뜻과 결합 우선순위는 [결정과 결합](/policy/rule/decision)에 있습니다. 사실 수집의 규율은
판단에 필요한 사실을 평가 시점에 읽어 오는 수집 경로인 PIP([자세히](/policy/runtime/pip))에
있습니다.

<Diagram name="evaluation-input-flow" title="평가 입력의 조립 — 무엇이 어디서 오는가" />

## 입력 문서의 세 구획

평가기에 들어가는 것은 완성된 입력 문서 하나입니다. Orchestrator가 세 구획을 모아 조립합니다.

```json
{
  "operation": "value_transfer",
  "principal": { "...": "정규화가 확정한 요청 사실" },
  "chain": { "...": "..." },
  "token": { "...": "..." },
  "amount": "...",
  "source_vault": { "...": "..." },
  "destination": { "...": "..." },
  "payload": { "...": "연산별 상세 — value_transfer v1은 sweep의 deposit_id 하나" },

  "address_ownership": { "...": "PIP 스냅샷 — 소스명이 최상위 키" },

  "_engine": {
    "tenant_id": "tnt-…",
    "obligations": { "...": "이행 맥락" },
    "workspace_bundle": { "rules": [], "slots": {} }
  }
}
```

- **정규화된 본문**: 요청이 주장한 사실을 대조 가능한 형태로 고정한 것입니다. `operation`과 그
  형제 키들이 여기에 해당하고, `payload`는 연산별 상세만 담습니다. 자세한 것은
  [정규화](/policy/runtime/normalization)에 있습니다.
- **PIP 스냅샷**: 소스명을 최상위 키로 나열합니다. 본문 키와 겹치면 조립을 실패로 종결합니다.
  수집한 사실이 요청 사실을 덮어쓰는 길을 막기 위해서입니다.
- **엔진 구획(`_engine`)**: 워크스페이스 번들, obligation 이행 맥락, 테넌트 식별자처럼 엔진이
  확정한 값이 들어가는 구획입니다. 요청이 이 구획을 채울 수 없습니다.

여기서 obligation은 통과로 확정되기 전에 이행해야 하는
조건입니다([룰 구조](/policy/rule/structure)).

값 이동 세 연산은 canonical에서 `value_transfer` 하나로 모입니다. 그래서 `operation`은 파트너
대상 API의 연산 이름과 1:1이 아닙니다. 최상위 키로 나열되는 PIP 스냅샷은 평가 루프에서 수집하는
소스이고, 지금 그것은 `address_ownership` 하나입니다.

**워크스페이스 구획은 빠뜨릴 수 없는 키입니다.** 구획이 없거나 모양이 어긋나면 커널은 평가에
진입하지 않고 `WORKSPACE_BUNDLE_INVALID`로 종결합니다. 커널이 런타임 기본값을 갖지 않기
때문입니다.

그래서 조정할 값이 없는 워크스페이스도 빈 구획 `{"rules": [], "slots": {}}`을 명시적으로 담아야
합니다. 룰 배열을 빼면 전송 중 사라진 구획이 "룰 없는 워크스페이스"로 읽히므로, 빈 룰 세트도
`"rules": []`로 적습니다. 조립하는 쪽이 키를 빼면 그 워크스페이스의 모든 요청이 막힙니다.

## 두 층의 룰 병합

룰은 `scope`와 조건을 갖고 `allow`·`deny`를 내는 단위입니다([룰 구조](/policy/rule/structure)).
커널은 조건 트리를 평가하고 결정을 결합하는 정책 무관 고정
부분입니다([결정과 결합](/policy/rule/decision)).

커널은 적재된 선언 트리의 플랫폼 룰과, 입력 문서에 담겨 온 워크스페이스 룰을 이어 붙여 하나의 룰
목록으로 평가합니다. 워크스페이스 번들은 한 워크스페이스가 소유하는 값 이동 룰과 슬롯 값입니다.
두 층은 같은 문법과 같은 해석기를 씁니다.

`scope`에 해당하지 않는 룰은 이 요청에 없는 것과 같고, 남은 룰만 `when` 판정에 들어갑니다.

**두 출처의 룰 ID가 하나라도 겹치면 그것만으로 종결합니다.** 결정은
`WORKSPACE_BUNDLE_INVALID`이고, 평가는 실행되지 않습니다. 이어 붙인 목록에서 같은 ID가 둘이면 룰별
판정을 담을 항목이 충돌하기 때문입니다.

컴파일은 번들 하나 안의 ID 유일성만 보증합니다. 두 층에 걸친 유일성은 커널이 봅니다. 그래서
워크스페이스 저작자가 플랫폼 룰 ID를 재사용하면 그 워크스페이스 전체가 막힙니다.

## 3치 조건 판정

조건 리프의 판정은 참·거짓·미지 셋이고, 미지는 입력에 없는 PIP 소스를 가리켰을 때만 나옵니다. 3치
규칙 전체는 [룰 명세](/policy/rule/reference)에 있습니다.

평가 흐름에서 중요한 것은 미지의 결과입니다. **미지는 allow를 세우지 못하고**, 그 소스를 수집해
오라는 요구가 되어 다음 평가 라운드로 이어집니다. 평가 라운드는 한 판단 요청 안에서 평가가 몇
번째로 실행됐는지입니다([결정과 결합](/policy/rule/decision)).

## 슬롯 해석 우선순위 세 단계

슬롯은 카탈로그에 선언되고 워크스페이스가 조정할 수 있는 값입니다([룰 구조](/policy/rule/structure)).
`{"slot": "이름"}` 참조를 만나면 커널이 그 시점에 값을 찾습니다. 우선순위는 세 단계입니다.

1. 입력의 워크스페이스 번들에 있는 테넌트별 값
2. 워크스페이스 번들의 기본값
3. 선언 트리의 슬롯 카탈로그에 있는 플랫폼 기본값

**조건의 비교값과 obligation의 파라미터가 같은 해석을 거칩니다.** 그래서 승인에 필요한 최소
인원인 정족수도, 허용 목록도 워크스페이스가 조정한 값이 같은 규칙으로 적용됩니다. 하한을 평가 시점에 한 번 더
확인하는 이유는 [룰 구조](/policy/rule/structure)에 있습니다.

## 결정값 산출

커널은 [결정과 결합](/policy/rule/decision)이 정한 우선순위를 정해진 검사 순서로 집행합니다. 그
우선순위는 기본 거부, deny 최우선, 수집 요구, 모듈 AND, obligation입니다. 미평가 룰이 기록에 남는
규칙도 그 페이지에 있습니다.

## 채점과의 공통 계약

채점도 같은 커널과 같은 입력 계약을 씁니다. 테스트 벡터 케이스의 `input`이 완전한 문서를 요구하는
이유가 여기 있습니다. **채점이 넣는 입력과 평가기가 받는 입력이 같은 모양**이라, 벡터로 고정한
판정이 운영의 판정과 같은 코드 경로를 거칩니다.

## 다음으로

이 흐름의 각 조각이 어디에 저장되고 무엇이 네트워크를 오가는지는
[저장과 이동](/policy/runtime/storage)에 있습니다.
