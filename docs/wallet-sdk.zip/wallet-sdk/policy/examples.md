---
title: 예시 정책
description: 워크스페이스 시드에 들어 있는 룰 셋과 그 룰이 가르는 요청
---

_읽는 사람: 파트너사 개발자. 실제로 동작하는 룰 셋을 그대로 보고, 어떤 요청이 통과하고 어떤 요청이 막히는지 대조합니다._

이 페이지의 룰 셋은 예시로 지어낸 것이 아닙니다. Wallet SDK를 도입한 회사 하나인
워크스페이스([계정 계층](/accounts-wallets/accounts))가 등록되면 이 셋이 그 워크스페이스의 첫
번들이 됩니다. 그래서 아래 JSON은 파트너사가 처음 열어 보게 되는 룰과 같습니다.

세 룰은 각각 출금·집금·vault 이체를 허가합니다. 셋 다 `effect`가 `allow`이고, 어느 룰의 적용
범위에도 매치되지 않는 요청은 기본 거절(default deny)로 끝납니다. 조각의 뜻과 참조할 수 있는
필드는 [룰 쓰기](/policy/rules)에 있습니다.

## 출금은 등재된 외부 주소로만 나갑니다

```json
{
  "id": "withdrawal/allow-evm-external-address",
  "effect": "allow",
  "scope": {
    "all": [
      { "field": "operation", "op": "eq", "value": "value_transfer" },
      { "field": "chain.family", "op": "eq", "value": "evm" },
      { "field": "destination.type", "op": "eq", "value": "external_address" },
      { "field": "source_vault.kind", "op": "eq", "value": "custody" }
    ]
  },
  "when": { "field": "address_ownership.status", "op": "eq", "value": "active" }
}
```

적용 범위의 네 조건이 이 룰에 걸리는 요청을 가릅니다.

- `operation` = `value_transfer` : 출금·vault 이체·집금처럼 자산을 실제로 움직이는 연산 셋인 값 이동만 매치합니다([결정과 결합](/policy/rule/decision))
- `chain.family` = `evm` : EVM 계열 네트워크의 요청만 매치합니다
- `destination.type` = `external_address` : 목적지가 외부 주소인 요청만 매치합니다. 내부 vault로 가는 집금과 vault 이체는 여기 걸리지 않습니다
- `source_vault.kind` = `custody` : 출발이 custody vault인 요청만 매치합니다. deposit vault에서 나가는 이동은 여기 걸리지 않습니다

조건은 하나입니다. `address_ownership.status`가 `active`인지를 봅니다. 이 값은 요청이 담아 오지
않고, 룰이 참조하는 외부 사실의 출처인 PIP 소스([자세히](/policy/runtime/pip))가 평가 도중
채웁니다.

통과하는 요청입니다. 등재 상태가 `active`인 외부 주소로 나가는 EVM 출금입니다.

- `operation` : `value_transfer`
- `chain.family` : `evm`
- `destination.type` : `external_address`
- `source_vault.kind` : `custody`
- `address_ownership.status` : `active`

막히는 요청입니다. 나머지는 같고 목적지 주소가 주소록에 없습니다.

- `destination.type` : `external_address`
- `source_vault.kind` : `custody`
- `address_ownership.status` : `unregistered`

**이 거절은 기본 거절이 아닙니다.** 적용 범위는 매치됐고 조건이 불성립한 것이라, 결정 사유가 이
모듈과 이 룰을 지목합니다. 회수된 주소도 상태가 `revoked`로 바뀌어 같은 경로로 막힙니다.

통과 방향의 끝에는 승인할 때 정해져 소비 시점에 적용되는 유효값인 승인 스탬프 둘이 함께
찍힙니다([자세히](/policy/runtime/normalization)). 인가 유효 시간과 건당 자원 상한이고, 두 값은
이 룰이 아니라 슬롯 `approved_intent_ttl_seconds`·`resource_limit_per_tx`에서 옵니다.

## 집금은 deposit 지갑에서 custody 지갑으로만 모입니다

```json
{
  "id": "sweep/allow-evm-deposit-to-custody",
  "effect": "allow",
  "scope": {
    "all": [
      { "field": "operation", "op": "eq", "value": "value_transfer" },
      { "field": "principal.type", "op": "eq", "value": "service" },
      { "field": "chain.family", "op": "eq", "value": "evm" },
      { "field": "destination.type", "op": "eq", "value": "internal_vault" },
      { "field": "source_vault.kind", "op": "eq", "value": "deposit" },
      { "field": "destination.vault_kind", "op": "eq", "value": "custody" }
    ]
  }
}
```

집금은 계정 지갑 자산을 워크스페이스 vault로 모으는 이동입니다([자세히](/fund-flows/sweep)).
적용 범위의 여섯 조건이 그 이동 하나만 남깁니다.

- `operation` = `value_transfer` : 값 이동만 매치합니다
- `principal.type` = `service` : 파트너사 서비스가 낸 요청만 매치합니다. 최종 사용자가 직접 내는 경로가 생겨도 이 룰이 그것을 함께 허가하지 않습니다
- `chain.family` = `evm` : EVM 계열 네트워크의 요청만 매치합니다
- `destination.type` = `internal_vault` : 목적지가 내부 vault인 요청만 매치합니다. 외부 주소로 나가는 집금은 여기 걸리지 않습니다
- `source_vault.kind` = `deposit` : 출발이 deposit vault인 요청만 매치합니다. custody vault에서 출발하는 이동과 갈립니다
- `destination.vault_kind` = `custody` : 목적지가 custody vault인 요청만 매치합니다. 다른 deposit vault로 흐르는 이동은 여기 걸리지 않습니다

조건 절이 없습니다. 적용 범위가 매치되면 그대로 허가이고, 수집 없이 평가 한 번으로 끝납니다.
대량으로 자주 일어나는 연산이라 PIP 참조를 두지 않은 것입니다.

통과하는 요청입니다.

- `operation` : `value_transfer`
- `principal.type` : `service`
- `chain.family` : `evm`
- `destination.type` : `internal_vault`
- `source_vault.kind` : `deposit`
- `destination.vault_kind` : `custody`

**막히는 요청은 목적지가 외부 주소인 집금입니다.** 출금 룰은 출발이 custody vault라야 매치되고
이 룰은 목적지가 내부 vault라야 매치되므로, 이 요청은 어느 allow에도 걸리지 않고 기본 거절로
끝납니다.

- `destination.type` : `external_address`
- `source_vault.kind` : `deposit`

이 룰이 내는 통과 결정에도 커널이 승인 스탬프 둘을 같은 슬롯 둘에서 읽어 찍습니다.

## 내부 이체는 custody 지갑 사이에서만 일어납니다

```json
{
  "id": "custody-transfer/allow-evm-internal-custody",
  "effect": "allow",
  "scope": {
    "all": [
      { "field": "operation", "op": "eq", "value": "value_transfer" },
      { "field": "chain.family", "op": "eq", "value": "evm" },
      { "field": "destination.type", "op": "eq", "value": "internal_vault" },
      { "field": "source_vault.kind", "op": "eq", "value": "custody" },
      { "field": "destination.vault_kind", "op": "eq", "value": "custody" }
    ]
  }
}
```

vault 이체는 워크스페이스 vault 사이의 이동입니다([자세히](/fund-flows/vault-transfer)). 적용
범위의 다섯 조건이 그 이동을 가릅니다.

- `operation` = `value_transfer` : 값 이동만 매치합니다
- `chain.family` = `evm` : EVM 계열 네트워크의 요청만 매치합니다
- `destination.type` = `internal_vault` : 목적지가 내부 vault인 요청만 매치합니다
- `source_vault.kind` = `custody` : 출발이 custody vault인 요청만 매치합니다. deposit vault에서 출발하는 집금과 갈립니다
- `destination.vault_kind` = `custody` : 목적지가 custody vault인 요청만 매치합니다

**목적지가 deposit vault인 이동은 여기 없습니다.** 자금 흐름에 custody에서 deposit으로
되돌리는 방향이 없기 때문입니다.

통과하는 요청입니다.

- `operation` : `value_transfer`
- `chain.family` : `evm`
- `destination.type` : `internal_vault`
- `source_vault.kind` : `custody`
- `destination.vault_kind` : `custody`

막히는 요청입니다. 나머지는 같고 목적지 vault가 deposit입니다. 어느 allow에도 걸리지 않아 기본
거절로 끝납니다.

- `source_vault.kind` : `custody`
- `destination.vault_kind` : `deposit`

여기서도 통과 결정에 승인 스탬프 둘이 같은 슬롯 둘에서 와서 찍힙니다.

## 예시에 없는 것 셋에는 각각 이유가 있습니다

세 룰이 다루지 않는 것이 셋입니다. 하나는 쓸 수 있으나 실물이 없고, 둘은 지금 쓸 수 없습니다.

- **deny 룰**: 룰 스키마는 `effect`에 `deny`를 허용하고, deny 룰에는 통과로 확정되기 전에 이행해야 하는 조건인 obligation을 달 수 없습니다. deny 룰은 지금도 쓸 수 있습니다. 시드에 실물이 없어 이 페이지에 싣지 않는 것뿐입니다. 계약은 [룰 명세](/policy/rule/reference)에, deny가 허가를 덮는 사례는 [금지선](/policy/use-cases/deny-override)에 있습니다
- **자산별 금액 상한 조건**: 금액 리터럴의 순서 비교는 컴파일 검사가 거부합니다. 그래서 상한은 금액 슬롯을 참조해서만 씁니다. 값 이동 금액 슬롯은 자산마다 엔트리를 요구하는데, 그 자산 키는 `token_catalog` 수집이 동작한 뒤에 정해집니다
- **서명 연산의 정족수**: 정족수는 승인이 성립하는 데 필요한 최소 승인자 수입니다. 지금 서명 연산에는 obligation 루프가 없어 정족수를 요구할 곳이 없고, 세 룰의 통과 방향 끝이 그대로 `allow`인 것도 같은 이유입니다

여러 룰의 결정이 하나로 합쳐지는 규칙은 [결정과 결합](/policy/rule/decision)에 있습니다. 조건
하나가 수집 루프를 발동하는 흐름은 [출금 화이트리스트](/policy/use-cases/whitelist-loop)가
처음부터 끝까지 따라갑니다.

## 다음으로

- [룰 저작과 발행](/policy/workflow) — 이 룰을 고쳐 발행할 때 거치는 절차
- [결과 읽기](/policy/results) — 거절과 보류가 파트너 대상 API 응답에 나타나는 곳
- [룰 쓰기](/policy/rules) — 조각의 뜻과 참조할 수 있는 필드 전체
